package com.simplemsg.app

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.simplemsg.app.databinding.ItemMessageBinding

class MessageAdapter(
    private val myUid: String,
    private val items: MutableList<ChatMessage> = mutableListOf()
) : RecyclerView.Adapter<MessageAdapter.VH>() {

    inner class VH(val binding: ItemMessageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemMessageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val msg = items[position]
        holder.binding.messageBubble.text = msg.text
        val params = holder.binding.messageBubble.layoutParams as android.widget.LinearLayout.LayoutParams
        if (msg.from == myUid) {
            params.gravity = Gravity.END
            holder.binding.messageBubble.setBackgroundResource(R.drawable.bubble_bg)
        } else {
            params.gravity = Gravity.START
            holder.binding.messageBubble.setBackgroundColor(Color.parseColor("#E0E0E0"))
            holder.binding.messageBubble.setTextColor(Color.BLACK)
        }
        holder.binding.messageBubble.layoutParams = params
    }

    override fun getItemCount() = items.size

    fun submit(newItems: List<ChatMessage>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}

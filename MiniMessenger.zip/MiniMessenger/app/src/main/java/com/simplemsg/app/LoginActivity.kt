package com.simplemsg.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simplemsg.app.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Автовход, если аккаунт уже сохранён на устройстве
        val savedUid = Prefs.getSavedUid(this)
        if (savedUid != null) {
            goToChats()
            return
        }

        binding.loginButton.setOnClickListener {
            val password = binding.passwordInput.text?.toString()?.trim().orEmpty()
            if (password.length < 4) {
                Toast.makeText(this, "Пароль должен быть от 4 символов", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            login(password)
        }
    }

    private fun login(password: String) {
        binding.loginProgress.visibility = android.view.View.VISIBLE
        binding.loginButton.isEnabled = false

        val uid = Crypto.uidFromPassword(password)
        val defaultNickname = "user_" + uid.take(6)

        Repo.ensureAccount(uid, defaultNickname) { profile ->
            Prefs.saveSession(this, uid)
            Prefs.saveNickname(this, profile.nickname)
            binding.loginProgress.visibility = android.view.View.GONE
            goToChats()
        }
    }

    private fun goToChats() {
        startActivity(Intent(this, ChatsActivity::class.java))
        finish()
    }
}

package com.simplemsg.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.simplemsg.app.databinding.ItemChatBinding

class ChatsAdapter(
    private val items: MutableList<ChatSummary>,
    private val onClick: (ChatSummary) -> Unit
) : RecyclerView.Adapter<ChatsAdapter.VH>() {

    inner class VH(val binding: ItemChatBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemChatBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.binding.chatNick.text = item.otherNick
        holder.binding.chatLastMsg.text = item.lastMessage
        holder.binding.root.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size

    fun submit(newItems: List<ChatSummary>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}

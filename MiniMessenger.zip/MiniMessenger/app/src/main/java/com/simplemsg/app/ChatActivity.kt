package com.simplemsg.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.database.ValueEventListener
import com.simplemsg.app.databinding.ActivityChatBinding

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private lateinit var myUid: String
    private lateinit var otherUid: String
    private lateinit var chatId: String
    private lateinit var adapter: MessageAdapter
    private var msgListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        myUid = Prefs.getSavedUid(this) ?: run {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }
        chatId = intent.getStringExtra("chatId") ?: return
        otherUid = intent.getStringExtra("otherUid") ?: return
        val otherNick = intent.getStringExtra("otherNick") ?: otherUid.take(6)

        binding.chatToolbar.title = otherNick
        binding.chatToolbar.setNavigationIcon(android.R.drawable.ic_menu_revert)
        binding.chatToolbar.setNavigationOnClickListener { finish() }

        adapter = MessageAdapter(myUid)
        binding.messagesList.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.messagesList.adapter = adapter

        msgListener = Repo.listenMessages(chatId) { list ->
            adapter.submit(list)
            binding.messagesList.scrollToPosition(maxOf(0, list.size - 1))
        }

        binding.sendButton.setOnClickListener {
            val text = binding.messageInput.text?.toString()?.trim().orEmpty()
            if (text.isNotEmpty()) {
                Repo.sendMessage(chatId, myUid, text)
                binding.messageInput.setText("")
            }
        }

        binding.audioCallBtn.setOnClickListener { startCall(video = false) }
        binding.videoCallBtn.setOnClickListener { startCall(video = true) }
    }

    private fun startCall(video: Boolean) {
        val intent = Intent(this, CallActivity::class.java)
        intent.putExtra("myUid", myUid)
        intent.putExtra("otherUid", otherUid)
        intent.putExtra("isCaller", true)
        intent.putExtra("video", video)
        intent.putExtra("callId", Repo.createCallId(myUid, otherUid))
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        msgListener?.let { Repo.removeListener("chats/$chatId/messages", it) }
    }
}

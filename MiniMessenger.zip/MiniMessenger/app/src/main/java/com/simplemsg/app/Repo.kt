package com.simplemsg.app

import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

object Repo {
    private val db get() = Firebase.database
    private val usersRef get() = db.getReference("users")
    private val nickIndexRef get() = db.getReference("nick_index")
    private val chatsRef get() = db.getReference("chats")
    private val callsRef get() = db.getReference("calls")

    // ---------- Аккаунт ----------

    fun ensureAccount(uid: String, defaultNickname: String, onDone: (UserProfile) -> Unit) {
        usersRef.child(uid).get().addOnSuccessListener { snap ->
            if (snap.exists()) {
                val nick = snap.child("nickname").getValue(String::class.java) ?: defaultNickname
                onDone(UserProfile(uid, nick))
            } else {
                val profile = mapOf(
                    "nickname" to defaultNickname,
                    "lastSeen" to System.currentTimeMillis()
                )
                usersRef.child(uid).setValue(profile)
                nickIndexRef.child(defaultNickname).setValue(uid)
                onDone(UserProfile(uid, defaultNickname))
            }
        }
    }

    fun updateNickname(uid: String, oldNick: String?, newNick: String, onDone: (Boolean) -> Unit) {
        nickIndexRef.child(newNick).get().addOnSuccessListener { snap ->
            if (snap.exists() && snap.getValue(String::class.java) != uid) {
                onDone(false) // ник занят
            } else {
                usersRef.child(uid).child("nickname").setValue(newNick)
                nickIndexRef.child(newNick).setValue(uid)
                if (!oldNick.isNullOrEmpty() && oldNick != newNick) {
                    nickIndexRef.child(oldNick).removeValue()
                }
                onDone(true)
            }
        }
    }

    fun findUidByNickname(nickname: String, onResult: (String?) -> Unit) {
        nickIndexRef.child(nickname).get().addOnSuccessListener { snap ->
            onResult(snap.getValue(String::class.java))
        }.addOnFailureListener { onResult(null) }
    }

    fun getNickname(uid: String, onResult: (String) -> Unit) {
        usersRef.child(uid).child("nickname").get().addOnSuccessListener {
            onResult(it.getValue(String::class.java) ?: uid.take(6))
        }
    }

    // ---------- Чаты и сообщения ----------

    fun openOrCreateChat(myUid: String, otherUid: String, onDone: (String) -> Unit) {
        val chatId = Crypto.chatIdFor(myUid, otherUid)
        val meta = mapOf("members" to mapOf(myUid to true, otherUid to true))
        chatsRef.child(chatId).child("meta").updateChildren(meta)
        onDone(chatId)
    }

    fun listenMyChats(myUid: String, onChats: (List<String>) -> Unit): ValueEventListener {
        val ref = chatsRef
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ids = mutableListOf<String>()
                for (chatSnap in snapshot.children) {
                    val members = chatSnap.child("meta").child("members")
                    if (members.hasChild(myUid)) ids.add(chatSnap.key ?: continue)
                }
                onChats(ids)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(listener)
        return listener
    }

    fun sendMessage(chatId: String, fromUid: String, text: String) {
        val id = chatsRef.child(chatId).child("messages").push().key ?: return
        val msg = mapOf(
            "from" to fromUid,
            "text" to text,
            "ts" to ServerValue.TIMESTAMP
        )
        chatsRef.child(chatId).child("messages").child(id).setValue(msg)
    }

    fun listenMessages(chatId: String, onMessages: (List<ChatMessage>) -> Unit): ValueEventListener {
        val ref = chatsRef.child(chatId).child("messages").orderByChild("ts")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = snapshot.children.map { s ->
                    ChatMessage(
                        id = s.key ?: "",
                        from = s.child("from").getValue(String::class.java) ?: "",
                        text = s.child("text").getValue(String::class.java) ?: "",
                        ts = s.child("ts").getValue(Long::class.java) ?: 0L
                    )
                }
                onMessages(list)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        ref.addValueEventListener(listener)
        return listener
    }

    fun removeListener(path: String, listener: ValueEventListener) {
        db.getReference(path).removeEventListener(listener)
    }

    // ---------- Сигналинг звонков (WebRTC) ----------
    // calls/{callId}: caller, callee, type(audio/video), status, offer, answer,
    //                 candidates_caller/{...}, candidates_callee/{...}

    fun callsRoot(): DatabaseReference = callsRef

    fun createCallId(uidA: String, uidB: String): String =
        Crypto.chatIdFor(uidA, uidB) + "_" + System.currentTimeMillis()
}

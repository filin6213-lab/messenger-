package com.simplemsg.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.database.*
import com.simplemsg.app.databinding.ActivityCallBinding
import org.webrtc.*

class CallActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCallBinding

    private lateinit var myUid: String
    private lateinit var otherUid: String
    private lateinit var callId: String
    private var isCaller: Boolean = true
    private var isVideo: Boolean = true

    private lateinit var eglBase: EglBase
    private var factory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var localAudioTrack: AudioTrack? = null
    private var localVideoTrack: VideoTrack? = null
    private var videoCapturer: VideoCapturer? = null
    private var muted = false

    private val callRef by lazy { Repo.callsRoot().child(callId) }
    private var remoteCandidatesListener: ChildEventListener? = null

    private val permissionRequestCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        myUid = intent.getStringExtra("myUid") ?: return finish()
        otherUid = intent.getStringExtra("otherUid") ?: return finish()
        callId = intent.getStringExtra("callId") ?: return finish()
        isCaller = intent.getBooleanExtra("isCaller", true)
        isVideo = intent.getBooleanExtra("video", true)

        binding.hangupBtn.setOnClickListener { endCall() }
        binding.muteBtn.setOnClickListener { toggleMute() }

        if (hasPermissions()) {
            initAndStart()
        } else {
            requestPermissions()
        }
    }

    private fun hasPermissions(): Boolean {
        val audioOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val camOk = !isVideo || ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        return audioOk && camOk
    }

    private fun requestPermissions() {
        val perms = if (isVideo) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                    else arrayOf(Manifest.permission.RECORD_AUDIO)
        ActivityCompat.requestPermissions(this, perms, permissionRequestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            if (hasPermissions()) initAndStart() else finish()
        }
    }

    // ---------- WebRTC setup ----------

    private fun initAndStart() {
        eglBase = EglBase.create()
        binding.localView.init(eglBase.eglBaseContext, null)
        binding.remoteView.init(eglBase.eglBaseContext, null)
        binding.localView.setMirror(true)
        binding.localView.visibility = if (isVideo) android.view.View.VISIBLE else android.view.View.GONE

        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(applicationContext)
                .createInitializationOptions()
        )

        val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)

        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()

        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        )
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)

        peerConnection = factory!!.createPeerConnection(rtcConfig, object : SimplePeerObserver() {
            override fun onIceCandidate(candidate: IceCandidate) {
                sendLocalCandidate(candidate)
            }

            override fun onAddStream(stream: MediaStream) {
                runOnUiThread {
                    stream.videoTracks.firstOrNull()?.addSink(binding.remoteView)
                }
            }

            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                runOnUiThread {
                    binding.callStatus.text = when (state) {
                        PeerConnection.IceConnectionState.CONNECTED -> "Соединено"
                        PeerConnection.IceConnectionState.DISCONNECTED -> "Отключено"
                        PeerConnection.IceConnectionState.FAILED -> "Сбой соединения"
                        else -> "Соединение..."
                    }
                }
            }
        })

        setupLocalMedia()
        listenRemoteSignaling()

        if (isCaller) createOffer() else listenForOffer()
    }

    private fun setupLocalMedia() {
        val audioConstraints = MediaConstraints()
        val audioSource = factory!!.createAudioSource(audioConstraints)
        localAudioTrack = factory!!.createAudioTrack("audio0", audioSource)

        val stream = factory!!.createLocalMediaStream("localStream")
        stream.addTrack(localAudioTrack)

        if (isVideo) {
            val videoCapturerAndSource = createVideoCapturer()
            if (videoCapturerAndSource != null) {
                videoCapturer = videoCapturerAndSource
                val surfaceHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.eglBaseContext)
                val videoSource = factory!!.createVideoSource(false)
                videoCapturer!!.initialize(surfaceHelper, this, videoSource.capturerObserver)
                videoCapturer!!.startCapture(640, 480, 30)
                localVideoTrack = factory!!.createVideoTrack("video0", videoSource)
                localVideoTrack!!.addSink(binding.localView)
                stream.addTrack(localVideoTrack)
            }
        }

        peerConnection?.addStream(stream)
    }

    private fun createVideoCapturer(): VideoCapturer? {
        val enumerator = Camera2Enumerator(this)
        for (name in enumerator.deviceNames) {
            if (enumerator.isFrontFacing(name)) {
                return enumerator.createCapturer(name, null)
            }
        }
        for (name in enumerator.deviceNames) {
            return enumerator.createCapturer(name, null)
        }
        return null
    }

    // ---------- Signaling через Firebase ----------

    private fun createOffer() {
        callRef.child("caller").setValue(myUid)
        callRef.child("callee").setValue(otherUid)
        callRef.child("type").setValue(if (isVideo) "video" else "audio")
        callRef.child("status").setValue("ringing")

        val constraints = MediaConstraints()
        peerConnection?.createOffer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription) {
                peerConnection?.setLocalDescription(SimpleSdpObserver(), desc)
                callRef.child("offer").setValue(mapOf("type" to desc.type.canonicalForm(), "sdp" to desc.description))
            }
        }, constraints)

        callRef.child("answer").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {}
            override fun onCancelled(error: DatabaseError) {}
        })
        callRef.child("answer").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                val type = snapshot.child("type").getValue(String::class.java) ?: return
                val desc = SessionDescription(SessionDescription.Type.fromCanonicalForm(type), sdp)
                peerConnection?.setRemoteDescription(SimpleSdpObserver(), desc)
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun listenForOffer() {
        callRef.child("offer").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val sdp = snapshot.child("sdp").getValue(String::class.java) ?: return
                val type = snapshot.child("type").getValue(String::class.java) ?: return
                val desc = SessionDescription(SessionDescription.Type.fromCanonicalForm(type), sdp)
                peerConnection?.setRemoteDescription(object : SimpleSdpObserver() {
                    override fun onSetSuccess() {
                        val constraints = MediaConstraints()
                        peerConnection?.createAnswer(object : SimpleSdpObserver() {
                            override fun onCreateSuccess(answerDesc: SessionDescription) {
                                peerConnection?.setLocalDescription(SimpleSdpObserver(), answerDesc)
                                callRef.child("answer").setValue(
                                    mapOf("type" to answerDesc.type.canonicalForm(), "sdp" to answerDesc.description)
                                )
                                callRef.child("status").setValue("accepted")
                            }
                        }, constraints)
                    }
                }, desc)
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun sendLocalCandidate(candidate: IceCandidate) {
        val node = if (isCaller) "candidates_caller" else "candidates_callee"
        val map = mapOf(
            "sdpMid" to candidate.sdpMid,
            "sdpMLineIndex" to candidate.sdpMLineIndex,
            "candidate" to candidate.sdp
        )
        callRef.child(node).push().setValue(map)
    }

    private fun listenRemoteSignaling() {
        val remoteNode = if (isCaller) "candidates_callee" else "candidates_caller"
        remoteCandidatesListener = callRef.child(remoteNode).addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                val sdpMid = snapshot.child("sdpMid").getValue(String::class.java) ?: return
                val sdpMLineIndex = snapshot.child("sdpMLineIndex").getValue(Int::class.java) ?: return
                val sdp = snapshot.child("candidate").getValue(String::class.java) ?: return
                peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex, sdp))
            }
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {}
        })

        callRef.child("status").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val status = snapshot.getValue(String::class.java)
                if (status == "ended") runOnUiThread { finish() }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun toggleMute() {
        muted = !muted
        localAudioTrack?.setEnabled(!muted)
        binding.muteBtn.text = if (muted) "🔇 Unmute" else "🎙 Mute"
    }

    private fun endCall() {
        callRef.child("status").setValue("ended")
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            videoCapturer?.stopCapture()
        } catch (_: Exception) {}
        videoCapturer?.dispose()
        peerConnection?.close()
        binding.localView.release()
        binding.remoteView.release()
    }
}

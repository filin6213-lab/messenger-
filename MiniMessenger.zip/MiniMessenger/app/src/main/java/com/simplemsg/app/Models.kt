package com.simplemsg.app

data class UserProfile(
    val uid: String = "",
    val nickname: String = "",
    val lastSeen: Long = 0L
)

data class ChatMessage(
    val id: String = "",
    val from: String = "",
    val text: String = "",
    val ts: Long = 0L
)

data class ChatSummary(
    val chatId: String = "",
    val otherUid: String = "",
    val otherNick: String = "",
    val lastMessage: String = ""
)

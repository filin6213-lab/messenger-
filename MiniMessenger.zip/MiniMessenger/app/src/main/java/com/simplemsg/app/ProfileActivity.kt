package com.simplemsg.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.simplemsg.app.databinding.ActivityProfileBinding

class ProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileBinding
    private lateinit var myUid: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        myUid = Prefs.getSavedUid(this) ?: run {
            startActivity(Intent(this, LoginActivity::class.java)); finish(); return
        }

        binding.profileToolbar.setNavigationIcon(android.R.drawable.ic_menu_revert)
        binding.profileToolbar.setNavigationOnClickListener { finish() }
        binding.myIdLabel.text = "ID аккаунта: $myUid"

        val savedNick = Prefs.getSavedNickname(this)
        binding.nicknameInput.setText(savedNick)

        binding.saveNicknameBtn.setOnClickListener {
            val newNick = binding.nicknameInput.text?.toString()?.trim().orEmpty()
            if (newNick.isEmpty()) {
                Toast.makeText(this, "Введите ник", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            Repo.updateNickname(myUid, savedNick, newNick) { ok ->
                if (ok) {
                    Prefs.saveNickname(this, newNick)
                    Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Такой ник уже занят", Toast.LENGTH_SHORT).show()
                }
            }
        }

        binding.logoutBtn.setOnClickListener {
            Prefs.clearSession(this)
            startActivity(Intent(this, LoginActivity::class.java))
            finishAffinity()
        }
    }
}

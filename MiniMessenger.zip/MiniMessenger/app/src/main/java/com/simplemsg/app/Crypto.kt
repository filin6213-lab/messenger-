package com.simplemsg.app

import java.security.MessageDigest

object Crypto {
    /**
     * Пароль детерминированно превращается в идентификатор аккаунта (uid).
     * Один и тот же пароль -> один и тот же аккаунт на любом устройстве.
     * Сам пароль никуда не передаётся и не сохраняется.
     */
    fun uidFromPassword(password: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(("minimsg_salt_v1:" + password).toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.substring(0, 32)
    }

    fun chatIdFor(uidA: String, uidB: String): String {
        return if (uidA < uidB) "${uidA}_$uidB" else "${uidB}_$uidA"
    }
}

package com.simplemsg.app

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.simplemsg.app.databinding.ActivityChatsBinding

class ChatsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatsBinding
    private lateinit var myUid: String
    private lateinit var adapter: ChatsAdapter
    private var chatsListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val uid = Prefs.getSavedUid(this)
        if (uid == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        myUid = uid

        binding.toolbar.title = "Чаты"
        binding.toolbar.menu.add("Профиль").setOnMenuItemClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
            true
        }

        adapter = ChatsAdapter(mutableListOf()) { chat ->
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("chatId", chat.chatId)
            intent.putExtra("otherUid", chat.otherUid)
            intent.putExtra("otherNick", chat.otherNick)
            startActivity(intent)
        }
        binding.chatsList.layoutManager = LinearLayoutManager(this)
        binding.chatsList.adapter = adapter

        binding.newChatFab.setOnClickListener { showAddChatDialog() }

        loadChats()
        listenIncomingCalls()
    }

    private var incomingCallListener: ChildEventListener? = null
    private val answeredCalls = mutableSetOf<String>()

    private fun listenIncomingCalls() {
        incomingCallListener = Repo.callsRoot().addChildEventListener(object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                handleCallSnapshot(snapshot)
            }
            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                handleCallSnapshot(snapshot)
            }
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun handleCallSnapshot(snapshot: DataSnapshot) {
        val callee = snapshot.child("callee").getValue(String::class.java) ?: return
        val caller = snapshot.child("caller").getValue(String::class.java) ?: return
        val status = snapshot.child("status").getValue(String::class.java) ?: return
        val callId = snapshot.key ?: return
        if (callee != myUid || status != "ringing" || answeredCalls.contains(callId)) return
        answeredCalls.add(callId)
        val isVideo = snapshot.child("type").getValue(String::class.java) == "video"

        Repo.getNickname(caller) { nick ->
            MaterialAlertDialogBuilder(this)
                .setTitle("Входящий звонок")
                .setMessage("$nick звонит вам (${if (isVideo) "видео" else "аудио"})")
                .setPositiveButton("Ответить") { _, _ ->
                    val intent = Intent(this, CallActivity::class.java)
                    intent.putExtra("myUid", myUid)
                    intent.putExtra("otherUid", caller)
                    intent.putExtra("isCaller", false)
                    intent.putExtra("video", isVideo)
                    intent.putExtra("callId", callId)
                    startActivity(intent)
                }
                .setNegativeButton("Отклонить") { _, _ ->
                    Repo.callsRoot().child(callId).child("status").setValue("ended")
                }
                .setCancelable(false)
                .show()
        }
    }

    private fun loadChats() {
        chatsListener = Repo.listenMyChats(myUid) { chatIds ->
            val summaries = mutableListOf<ChatSummary>()
            var remaining = chatIds.size
            if (remaining == 0) {
                adapter.submit(emptyList())
                return@listenMyChats
            }
            for (chatId in chatIds) {
                val otherUid = chatId.replace(myUid, "").removePrefix("_").removeSuffix("_")
                Repo.getNickname(otherUid) { nick ->
                    summaries.add(ChatSummary(chatId, otherUid, nick, ""))
                    remaining--
                    if (remaining == 0) {
                        adapter.submit(summaries.sortedBy { it.otherNick })
                    }
                }
            }
        }
    }

    private fun showAddChatDialog() {
        val input = EditText(this)
        input.hint = "Никнейм собеседника"
        input.inputType = InputType.TYPE_CLASS_TEXT
        MaterialAlertDialogBuilder(this)
            .setTitle("Новый чат")
            .setView(input)
            .setPositiveButton("Начать") { _, _ ->
                val nick = input.text.toString().trim()
                if (nick.isEmpty()) return@setPositiveButton
                Repo.findUidByNickname(nick) { otherUid ->
                    if (otherUid == null) {
                        Toast.makeText(this, "Пользователь с таким ником не найден", Toast.LENGTH_SHORT).show()
                    } else if (otherUid == myUid) {
                        Toast.makeText(this, "Это ваш собственный аккаунт", Toast.LENGTH_SHORT).show()
                    } else {
                        Repo.openOrCreateChat(myUid, otherUid) { chatId ->
                            val intent = Intent(this, ChatActivity::class.java)
                            intent.putExtra("chatId", chatId)
                            intent.putExtra("otherUid", otherUid)
                            intent.putExtra("otherNick", nick)
                            startActivity(intent)
                        }
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        chatsListener?.let { Repo.removeListener("chats", it) }
        incomingCallListener?.let { Repo.callsRoot().removeEventListener(it) }
    }
}

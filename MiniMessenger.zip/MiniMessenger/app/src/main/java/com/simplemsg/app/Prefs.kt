package com.simplemsg.app

import android.content.Context

/**
 * Хранит на устройстве uid текущего аккаунта, чтобы при следующем запуске
 * пользователь заходил автоматически без повторного ввода пароля.
 * Сам пароль нигде не хранится в открытом виде — только его хэш (см. Crypto.kt),
 * а хэш используется как uid.
 */
object Prefs {
    private const val FILE = "minimsg_prefs"
    private const val KEY_UID = "uid"
    private const val KEY_NICK = "nickname"

    fun saveSession(context: Context, uid: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_UID, uid).apply()
    }

    fun getSavedUid(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_UID, null)

    fun clearSession(context: Context) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun saveNickname(context: Context, nickname: String) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_NICK, nickname).apply()
    }

    fun getSavedNickname(context: Context): String? =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_NICK, null)
}
